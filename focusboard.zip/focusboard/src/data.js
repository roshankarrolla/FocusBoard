export const STATUSES = ["To do", "In progress", "Completed"];
export const PRIORITIES = ["Low", "Medium", "High"];
export const SAMPLE_TASKS = [
  ["Design landing page","Create hero section and pricing layout.","Design","In progress","High","2026-12-01"],
  ["Write API docs","Document the public endpoints.","Docs","To do","Medium","2026-12-05"],
  ["Fix login bug","Resolve redirect loop after sign-in.","Bug","In progress","High","2026-11-28"],
  ["Team standup notes","Summarise the weekly standup.","Admin","Completed","Low","2026-11-20"],
  ["Plan sprint backlog","Prioritise stories for next sprint.","Planning","To do","Medium","2026-12-03"],
  ["Review pull requests","Review open PRs from the team.","Dev","Completed","Medium","2026-11-22"],
].map((t, i) => ({ id: "t" + (i + 1), title: t[0], description: t[1], category: t[2], status: t[3], priority: t[4], dueDate: t[5] }));
// TODO: replace with the exact text from the Figma Focus Notes frames (15:2, 15:30, 15:58)
export const SLIDES = [
  { title: "Plan your day", text: "Pick your top three tasks before opening anything else." },
  { title: "Work in focused blocks", text: "25 minutes of deep work, then a short break." },
  { title: "Review and reflect", text: "Close the day by moving finished tasks to Completed." },
];
