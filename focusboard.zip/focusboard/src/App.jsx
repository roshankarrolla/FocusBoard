import { useEffect, useMemo, useReducer, useState } from "react";
import { SAMPLE_TASKS, SLIDES, STATUSES, PRIORITIES } from "./data.js";

const KEY = "focusboard.tasks.v1";
function load() {
  try {
    const raw = localStorage.getItem(KEY);
    if (raw !== null) { const p = JSON.parse(raw); if (Array.isArray(p)) return p; }
  } catch {}
  return SAMPLE_TASKS; // only used when nothing is saved
}
function reducer(s, a) {
  switch (a.type) {
    case "add": return [{ ...a.task, id: crypto.randomUUID() }, ...s];
    case "edit": return s.map(t => (t.id === a.task.id ? { ...t, ...a.task } : t));
    case "delete": return s.filter(t => t.id !== a.id);
    case "status": return s.map(t => (t.id === a.id ? { ...t, status: a.status } : t));
    default: return s;
  }
}

function Stat({ label, value }) {
  return <div className="card stat"><span>{label}</span><strong>{value}</strong></div>;
}

function Carousel() {
  const [i, setI] = useState(0);
  const n = SLIDES.length;
  const s = SLIDES[i];
  return (
    <section className="card carousel" aria-roledescription="carousel" aria-label="Focus Notes">
      <button aria-label="Previous slide" onClick={() => setI((i + n - 1) % n)}>‹</button>
      <div className="slide" aria-live="polite">
        <small>Focus Notes · {i + 1} of {n}</small>
        <h3>{s.title}</h3><p>{s.text}</p>
        <div className="dots">
          {SLIDES.map((_, d) => (
            <button key={d} className={d === i ? "dot on" : "dot"} aria-label={`Go to slide ${d + 1}`}
              aria-current={d === i} onClick={() => setI(d)} />
          ))}
        </div>
      </div>
      <button aria-label="Next slide" onClick={() => setI((i + 1) % n)}>›</button>
    </section>
  );
}

function TaskForm({ task, onSave, onCancel }) {
  const [f, setF] = useState(task || { title: "", description: "", category: "General", status: "To do", priority: "Medium", dueDate: "" });
  const [err, setErr] = useState("");
  const set = k => e => setF({ ...f, [k]: e.target.value });
  const submit = e => {
    e.preventDefault();
    if (!f.title.trim()) return setErr("Title is required.");
    if (f.title.trim().length < 3) return setErr("Title must be at least 3 characters.");
    onSave({ ...f, title: f.title.trim() });
  };
  return (
    <div className="overlay" onKeyDown={e => e.key === "Escape" && onCancel()}>
      <form className="card modal" role="dialog" aria-modal="true" aria-labelledby="ft" onSubmit={submit} noValidate>
        <h2 id="ft">{task ? "Edit task" : "Create task"}</h2>
        <label>Title *
          <input autoFocus value={f.title} onChange={set("title")} aria-invalid={!!err} aria-describedby="terr" />
        </label>
        {err && <p id="terr" role="alert" className="error">{err}</p>}
        <label>Description<textarea rows="3" value={f.description} onChange={set("description")} /></label>
        <div className="row">
          <label>Status<select value={f.status} onChange={set("status")}>{STATUSES.map(x => <option key={x}>{x}</option>)}</select></label>
          <label>Priority<select value={f.priority} onChange={set("priority")}>{PRIORITIES.map(x => <option key={x}>{x}</option>)}</select></label>
          <label>Due date<input type="date" value={f.dueDate} onChange={set("dueDate")} /></label>
        </div>
        <div className="actions">
          <button type="button" className="ghost" onClick={onCancel}>Cancel</button>
          <button type="submit" className="primary">{task ? "Save changes" : "Create task"}</button>
        </div>
      </form>
    </div>
  );
}

export default function App() {
  const [tasks, dispatch] = useReducer(reducer, undefined, load);
  const [query, setQuery] = useState("");
  const [tab, setTab] = useState("All");
  const [prio, setPrio] = useState("All");
  const [form, setForm] = useState(null); // null | "new" | task
  const [del, setDel] = useState(null);
  const [nav, setNav] = useState(false);

  useEffect(() => { try { localStorage.setItem(KEY, JSON.stringify(tasks)); } catch {} }, [tasks]);

  const stats = useMemo(() => {
    const total = tasks.length;
    const done = tasks.filter(t => t.status === "Completed").length;
    return { total, done, prog: tasks.filter(t => t.status === "In progress").length, pct: total ? Math.round((done / total) * 100) : 0 };
  }, [tasks]);

  const shown = useMemo(() => {
    const q = query.trim().toLowerCase();
    return tasks.filter(t =>
      t.title.toLowerCase().includes(q) &&
      (tab === "All" || t.status === tab) &&
      (prio === "All" || t.priority === prio));
  }, [tasks, query, tab, prio]);

  const save = t => { dispatch({ type: form === "new" ? "add" : "edit", task: t }); setForm(null); };

  return (
    <div className="layout">
      <aside className={nav ? "sidebar open" : "sidebar"}>
        <div className="brand">● FocusBoard</div>
        <nav aria-label="Main">
          <a href="#" aria-current="page">Dashboard</a>
          <a href="#" onClick={e => e.preventDefault()}>Calendar</a>
          <a href="#" onClick={e => e.preventDefault()}>Settings</a>
        </nav>
      </aside>
      <main>
        <header className="top">
          <button className="menu ghost" aria-label="Toggle navigation" aria-expanded={nav} onClick={() => setNav(!nav)}>☰</button>
          <div><h1>Dashboard</h1><p className="muted">Stay on top of your work.</p></div>
          <button className="primary" onClick={() => setForm("new")}>+ New task</button>
        </header>

        <section className="stats" aria-label="Overview">
          <Stat label="Total tasks" value={stats.total} />
          <Stat label="In progress" value={stats.prog} />
          <Stat label="Completed" value={stats.done} />
          <div className="card stat"><span>Completion</span><strong>{stats.pct}%</strong>
            <div className="bar" role="progressbar" aria-valuenow={stats.pct} aria-valuemin="0" aria-valuemax="100"><i style={{ width: stats.pct + "%" }} /></div>
          </div>
        </section>

        <Carousel />

        <section className="card list">
          <div className="controls">
            <input type="search" placeholder="Search tasks…" aria-label="Search tasks by title" value={query} onChange={e => setQuery(e.target.value)} />
            <select aria-label="Filter by priority" value={prio} onChange={e => setPrio(e.target.value)}>
              {["All", ...PRIORITIES].map(p => <option key={p} value={p}>{p === "All" ? "All priorities" : p}</option>)}
            </select>
          </div>
          <div className="tabs" role="group" aria-label="Filter by status">
            {["All", ...STATUSES].map(s => <button key={s} aria-pressed={tab === s} className={tab === s ? "tab on" : "tab"} onClick={() => setTab(s)}>{s}</button>)}
          </div>
          <ul>
            {shown.map(t => (
              <li key={t.id} className="task">
                <div className="info">
                  <strong>{t.title}</strong>
                  <p className="muted">{t.description}</p>
                  <div className="meta">
                    <span className="badge">{t.category}</span>
                    <span className={"badge p-" + t.priority.toLowerCase()}>{t.priority}</span>
                    {t.dueDate && <span className="muted">Due {t.dueDate}</span>}
                  </div>
                </div>
                <div className="ops">
                  <select aria-label={`Status of ${t.title}`} value={t.status} onChange={e => dispatch({ type: "status", id: t.id, status: e.target.value })}>
                    {STATUSES.map(s => <option key={s}>{s}</option>)}
                  </select>
                  <button className="ghost" onClick={() => setForm(t)}>Edit</button>
                  <button className="ghost danger" onClick={() => setDel(t)}>Delete</button>
                </div>
              </li>
            ))}
          </ul>
          {!shown.length && <p className="muted empty">No tasks match your filters.</p>}
        </section>
      </main>

      {form && <TaskForm task={form === "new" ? null : form} onSave={save} onCancel={() => setForm(null)} />}
      {del && (
        <div className="overlay">
          <div className="card modal" role="alertdialog" aria-modal="true" aria-labelledby="dt">
            <h2 id="dt">Delete task?</h2>
            <p>“{del.title}” will be permanently removed.</p>
            <div className="actions">
              <button className="ghost" autoFocus onClick={() => setDel(null)}>Cancel</button>
              <button className="primary danger-bg" onClick={() => { dispatch({ type: "delete", id: del.id }); setDel(null); }}>Delete</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
