# AI Usage
**Tools:** Claude (Anthropic).  
**Prompts (examples):** 1) "Build FocusBoard per the assignment PDF." 2) _add your own_  
**AI-assisted areas:** initial scaffold, reducer, form validation, CSS.  
**Verified/corrected suggestion:** _Write one you actually checked (e.g. confirmed localStorage restore on refresh and that sample data doesn't overwrite saved data)._
