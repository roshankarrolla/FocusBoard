# FocusBoard
Single-user task dashboard (React 18 + Vite, plain CSS, no backend).

**Live URL:** _add Vercel/Netlify link_  
**Screenshots:** _add desktop + mobile PNGs in /screenshots_

## Setup
`npm install && npm run dev` · build: `npm run build`

## Implementation
Create/edit/delete (with confirm), status changes, case-insensitive title search + status tabs + priority filter (combined), derived stats, 3-slide Focus Notes carousel with indicators, localStorage persistence (samples only load when nothing is saved), semantic/keyboard-accessible markup, layouts at 390/768/1440.

## State management
`useReducer` holds the task list (single source of truth, pure immutable reducer); filters and statistics are derived with `useMemo`. Chosen because the app is small and needs no external library. Carousel index is local state.

## Limitations
- Sidebar links other than Dashboard are visual placeholders.
- Colors/spacing and Focus Notes text must be matched to the Figma frames (see TODO in `src/data.js`).
